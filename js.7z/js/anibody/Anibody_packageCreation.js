
Anibody.SetPackage("Anibody", "classes");
Anibody.SetPackage("Anibody", "classes", "Input");
Anibody.SetPackage("Anibody", "ui");
Anibody.SetPackage("Anibody", "util");
Anibody.SetPackage("Anibody", "visual");
Anibody.SetPackage("Anibody", "nav");
Anibody.SetPackage("Anibody", "debug");
Anibody.SetPackage("Anibody", "static");